
/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu.c                                                               */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/24                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/24
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "linktable.h"

#define SUCCESS 0
#define FAILURE (-1)
#define CMD_MAX_LEN 128


tDataNode * FindCmd(tLinkTable * pLinkTable, char * cmd);

int AddMenu(tLinkTable * pLinkTable, char * cmd, char * desc, int (* handler)());

int ShowCmd(tLinkTable * pLinkTable, char * cmd);

int showAllCmd(tLinkTable * pLinkTable);

int DeleteCmd(tLinkTable * pLinkTable,char * cmd);

int Help(tLinkTable * head);

int Exit(tLinkTable * head);

                            
/**************************************************************************************************/
/*                                                                                                */
/*                               Private      Fuction                                             */
/*                                                                                                */
/**************************************************************************************************/


/* find a cmd in the linklist and return the datanode pointer */
tDataNode * FindCmd(tLinkTable * pLinkTable, char * cmd)
{
    tDataNode * pNode = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode *)GetNextLinkTableNode(pLinkTable, (tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * pLinkTable)
{
    tDataNode * pNode = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(pNode != NULL)
    {
        printf("%s\t - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(pLinkTable, (tLinkTableNode *)pNode);
    }
    return SUCCESS;
}

/*add details of a cmd to the menu*/
int AddMenu(tLinkTable * pLinkTable, char * cmd, char * desc, int (*handler)())
{
    int state;
    tDataNode * pNode = (tDataNode *)malloc(sizeof(tDataNode));
    pNode->cmd = cmd;
    pNode->desc = desc;
    pNode->handler = handler;
    tLinkTableNode * p = (tLinkTableNode *)pNode;
    state = AddLinkTableNode(pLinkTable, p);
    return state;
}

/*delete a cmd from the menu*/
int DeleteCmd(tLinkTable * pLinkTable,char * cmd)
{
    tLinkTableNode * pNode = (tLinkTableNode *)FindCmd(pLinkTable, cmd);
    return DelLinkTableNode(pLinkTable, pNode);
}

/*show a cmd's description and execute its operation*/
int ShowCmd(tLinkTable * pLinkTable,char * cmd)
{ 
    tDataNode * pNode = FindCmd(pLinkTable, cmd);
    if(pNode == NULL)
    {
    	return FAILURE;
    }
    printf("%s\t - %s\n", pNode->cmd, pNode->desc);
    if(pNode->handler != NULL) 
    { 
        pNode->handler(pLinkTable);
    }
    return SUCCESS;
}

int Help(tLinkTable * head)
{
    ShowAllCmd(head);
    return SUCCESS;
}

int Exit(tLinkTable * head)
{
    exit(0);
}

tLinkTable * exmenu = NULL;

/**************************************************************************************************/
/*                                                                                                */
/*                               Private      Fuction                                             */
/*                                                                                                */
/**************************************************************************************************/

/*create a new menu program and return the head pointer*/
tLinkTable * CreateMenu()
{
    tLinkTable * head = CreateLinkTable();
    exmenu = CreateLinkTable();
    AddMenu(exmenu, "exit", "Quit!", Exit);
    AddMenu(exmenu, "help", "This is help cmd!", Help);
    AddMenu(exmenu, "version", "version 1.0", NULL);
    return head;
}

/*a driver that add the cmd and return its result*/
int AddCmd(tLinkTable * head)
{
    if(head == NULL)
    {
        return FAILURE;
    }
    else
    {
        return SUCCESS;
    }
    
/*    char cmd[CMD_MAX_LEN];
    int  state;
    while(1)
    {
        printf("Please input the Cmd you want to add:\n");
        scanf("%s", cmd);
        getchar();
        tDataNode * p = FindCmd(exmenu, cmd);
        if(p == NULL)
        {
            return FAILURE;
        }
        state = AddMenu(head, p->cmd, p->desc, p->handler);
        if(state != SUCCESS)
        {
            return state;
        }
    }
    return state;
*/
}

/*a driver that run the program and return its*/
int RunMenu(tLinkTable * head)
{
    if(head == NULL)
    {
        return FAILURE;
    }
    else
    {
        return SUCCESS;
    }
/*    char choice;
    int  state;
    char cmd[CMD_MAX_LEN];
    ShowAllCmd(head);
    while(1)
    {   
        if(head->pHead == NULL)
        {
            return FAILURE;
        }
        printf("Do you want to run the menu program or delete the cmd of the menu program:(r/d)");
        scanf("%c", &choice);  
        if(choice == 'r')
        {
            printf("Input a cmd > ");
            scanf("%s", cmd);
            getchar();
            state = ShowCmd(head, cmd);
            if(state != SUCCESS)
            {
                printf("This is a wrong cmd!\n");
            }
        }
        else if(choice == 'd')
        {  
            printf("Delete a cmd >");
            scanf("%s", cmd);
            getchar();
            state = DeleteCmd(head, cmd);
            if(state != SUCCESS)
            {
                printf("This is a wrong cmd!\n");
            }
            ShowAllCmd(head);
        }
        else 
        {
            printf("This is a wrong choice!\n");
            getchar();
        } 
    }
*/
}

/*delete the menu and return its result*/
int DeleteMenu(tLinkTable * head)
{
    if(head == NULL)
    {
        return FAILURE;
    }
    else
    {
        return SUCCESS;
    }
/*    return DeleteLinkTable(head);
*/
}





