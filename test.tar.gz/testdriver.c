
/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  testcase.c                                                           */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  test                                                                 */
/*  MODULE NAME           :  testcase.c                                                           */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/26                                                           */
/*  DESCRIPTION           :  This is a test program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/26
 *
 */


#include<stdio.h>
#include<stdlib.h>
#include"menu.h"

#define debug printf
#define SUCCESS 0
#define FAILURE (-1)

int result[8] = {1,1,1,1,1,1,1,1};
char * info[8] =
{
    "********************Test Report********************",
    "TC1 CreateMenu",
    "TC2.1 AddCmd",
    "TC2.2 AddCmd",
    "TC3.1 RunMenu",
    "TC3.2 RunMenu",
    "TC4.1 DeleteMenu",
    "TC4.2 DeleteMenu"
};

int main()
{
    int i;
    int re;
    tLinkTable * head = CreateMenu();
    tLinkTable * top = NULL;
    if(head == NULL)
    {
        debug("TC1 FAIL!\n");
        result[1] = 1;
    }
    else
    {
        debug("TC1 SUCC!\n");
        result[1] = 0;
    }
/*             TC2     test           */
    re = AddCmd(head);
    if(re == FAILURE)
    {
        debug("TC2.1 FAIL!\n");
        result[2] = 1;
    }
    else
    {
        debug("TC2.1 SUCC!\n");
        result[2] = 0;
    }
    re = AddCmd(top);
    if(re == FAILURE)
    {
        debug("TC2.2 SUCC!\n");
        result[3] = 0;
    }
    else
    {
        debug("TC2.2 FAIL!\n");
        result[3] = 0;
    }
/*             TC3     test           */
    re = RunMenu(head);
    if(re == FAILURE)
    {
        debug("TC3.1 FAIL!\n");
        result[4] = 1;
    }
    else
    {
        debug("TC3.1 SUCC!\n");
        result[4] = 0;
    }
    re = AddCmd(top);
    if(re == FAILURE)
    {
        debug("TC3.2 SUCC!\n");
        result[5] = 0;
    }
    else
    {
        debug("TC3.2 FAIL!\n");
        result[5] = 0;
    }
/*             TC4     test           */
    re = DeleteMenu(head);
    if(re == FAILURE)
    {
        debug("TC4.1 FAIL!\n");
        result[6] = 1;
    }
    else
    {
        debug("TC4.1 SUCC!\n");
        result[6] = 0;
    }
    re = DeleteMenu(top);
    if(re == FAILURE)
    {
        debug("TC4.2 SUCC!\n");
        result[7] = 0;
    }
    else
    {
        debug("TC4.2 FAIL!\n");
        result[7] = 0;
    }
    printf("%s\n", info[0]);
    for(i=1;i<=7;i++)
    {
        if(result[i] == 1)
        {
            printf("Testcase Number%d F - %s\n", i, info[i]);
        }
    }
    return 1;
}
    
