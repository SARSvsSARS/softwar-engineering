/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu.c                                                               */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/20
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "linktable.h"

#define SUCCESS 0
#define FAILURE (-1)

typedef int (*handler)();

/*create a new menu program and return the head pointer*/
tLinkTable * CreateMenu()
{
    tLinkTable * head=CreateLinkTable();
    return head;
}

/* find a cmd in the linklist and return the datanode pointer */
tDataNode * FindCmd(tLinkTable * pLinkTable, char * cmd)
{
    tDataNode * pNode = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(pNode != NULL)
    {
        if(!strcmp(pNode->cmd, cmd))
        {
            return  pNode;  
        }
        pNode = (tDataNode *)GetNextLinkTableNode(pLinkTable, (tLinkTableNode *)pNode);
    }
    return NULL;
}

/* show all cmd in listlist */
int ShowAllCmd(tLinkTable * pLinkTable)
{
    tDataNode * pNode = (tDataNode *)GetLinkTableHead(pLinkTable);
    while(pNode != NULL)
    {
        printf("%s\t - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(pLinkTable, (tLinkTableNode *)pNode);
    }
    return SUCCESS;
}

/*add*/
int AddMenu(tLinkTable * pLinkTable, char * cmd, char * desc, int (*handler)())
{
    int state;
    tDataNode * pNode = (tDataNode *)malloc(sizeof(tDataNode));
    pNode->cmd = cmd;
    pNode->desc = desc;
    pNode->handler = handler;
    tLinkTableNode * p = (tLinkTableNode *)pNode;
    state = AddLinkTableNode(pLinkTable, p);
    return state;
}

int DeleteMenu(tLinkTable * pLinkTable)
{
    return DeleteLinkTable(pLinkTable);
}

int DeleteCmd(tLinkTable * pLinkTable,char * cmd)
{
    tLinkTableNode * pNode = (tLinkTableNode *)FindCmd(pLinkTable, cmd);
    return DelLinkTableNode(pLinkTable, pNode);
}

int ShowCmd(tLinkTable * pLinkTable,char * cmd)
{ 
    tDataNode * pNode = FindCmd(pLinkTable, cmd);
    if(pNode == NULL)
    {
    	return FAILURE;
    }
    printf("%s\t - %s\n", pNode->cmd, pNode->desc);
    if(pNode->handler != NULL) 
        { 
            pNode->handler();
        }
    return SUCCESS;
}



