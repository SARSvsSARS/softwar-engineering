/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/17                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/
/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"

int Help();

#define DESC_LEN    1024
#define CMD_MAX_LEN    128

/* menu program and inti CmdList*/

static tDataNode head[] =
{
    {"help", "This is help cmd!", Help, &head[1]},
    {"version", "menu program v1.0", NULL, NULL}
};

void main()
{  
    while(1)
    {
        char cmd[CMD_MAX_LEN];
        printf("Input a cmd string > ");
        scanf("%s", cmd);
        tDataNode * p=FindCmd(head, cmd);
        if(p==NULL)
        {
            printf("This is a wrong cmd string!\n");
        }
        else
        {
        printf("%s\t:    %s\n", p->cmd, p->desc);
            if(p->operation!=NULL)
            {
                p->operation();
            }
        }
    }
}

int Help()
{ ShowCmd(head);
return 0;
}
