/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu.h                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/20
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include "linktable.h"

#ifndef _MENU_H_
#define _MENU_H_

#include <pthread.h>
#include "linktable.h"

#define SUCCESS 0
#define FAILURE (-1)

typedef struct DataNode
{
    tLinkTableNode * pNext;
    char * cmd;
    char * desc;
    int    (*handler)();
} tDataNode;

tLinkTable * CreateMenu();

tDataNode * FindCmd(tLinkTable * pLinkTable, char * cmd);

int DeleteMenu(tLinkTable * pLinkTable);

int AddMenu(tLinkTable * pLinkTable, char * cmd, char * desc, int (* handler)());

int ShowCmd(tLinkTable * pLinkTable, char * cmd);

int showAllCmd(tLinkTable * pLinkTable);

int DeleteCmd(tLinkTable * pLinkTable,char * cmd);


#endif

