/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/20                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/20
 *
 */
 
#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define CMD_MAX_LEN 128

tLinkTable * head = NULL;

int Help()
{
    ShowAllCmd(head);
    return SUCCESS;
}

int main()
{   
    char choice;
    int  state;
    char cmd[CMD_MAX_LEN];
    head = CreateMenu();
    AddMenu(head, "help", "This is help cmd!", Help);
    AddMenu(head, "version", "version 1.0", NULL);
    ShowAllCmd(head);
    while(1)
    {   
        printf("Do you want to run the menu program or delete the cmd of the menu program:(r/d)");
        scanf("%c", &choice);  
        if(choice == 'r')
        {
            printf("Input a cmd > ");
            scanf("%s", cmd);
            getchar();
            state = ShowCmd(head, cmd);
            if(state != SUCCESS)
            {
                printf("This is a wrong cmd!\n");
            }
        }
        else if(choice == 'd')
        {  
            printf("Delete a cmd >");
            scanf("%s", cmd);
            getchar();
            state = DeleteCmd(head, cmd);
            if(state != SUCCESS)
            {
                printf("This is a wrong cmd!\n");
            }
            ShowAllCmd(head);
        }
        else 
        {
            printf("This is a wrong choice!\n");
            getchar();
        } 
    }
}



