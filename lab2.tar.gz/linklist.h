/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  linklist.h                                                           */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  linklist                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/17                                                           */
/*  DESCRIPTION           :  linklist for menu program                                            */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
 
typedef struct DataNode
{
    char *   cmd;
    char *   desc;
    int      (*operation)();
    struct   DataNode *next;
} tDataNode;

tDataNode * FindCmd(tDataNode * head, char * cmd);

int ShowCmd(tDataNode * head);
