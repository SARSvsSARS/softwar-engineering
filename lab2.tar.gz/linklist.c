/**************************************************************************************************/
/* Copyright (C)             ZK@USTC, 2014-2015                                                   */
/*                                                                                                */
/*  FILE NAME             :  linklist.c                                                           */
/*  PRINCIPAL AUTHOR      :  ZhangKun                                                             */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  linklist                                                             */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/17                                                           */
/*  DESCRIPTION           :  linklist for menu program                                            */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by ZhangKun, 2014/09/17
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"

/* Data's Operations*/

int ShowCmd(tDataNode * head)
{
    tDataNode * p = head;
    printf("Menu List:\n");
    while(p!=NULL)
    {
        printf("%s\t:    %s\n", p->cmd, p->desc);
        p=p->next;
    }
    return 0;
}

tDataNode * FindCmd(tDataNode * head, char * cmd)
{
    tDataNode * p = head;
    if(p==NULL||cmd==NULL)
    {
        printf("This is a wrong cmd string!\n");
    }    
    while(p != NULL)
    {
        if(strcmp(p->cmd,cmd)==0)
        {
            return p;
        }
        p = p->next;
    }
    return p;
}
