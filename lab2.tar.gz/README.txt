This is a testmenu program!
Build Procedure
$ gcc linktable.c menu.c testmenu.c -o menu
$ ./menu 
# you can input r/d to run menu program / delete cmd
# if you run menu program, you can input help / version cmd
# if you delete program, you can input help / version to delete help cmd / version cmd
